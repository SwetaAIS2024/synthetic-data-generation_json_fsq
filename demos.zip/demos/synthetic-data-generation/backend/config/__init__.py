import os
from dotenv import load_dotenv

from .config import Config

load_dotenv()
